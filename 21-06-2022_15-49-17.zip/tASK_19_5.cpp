#include <iostream>
#include <fstream>
#include <vector>


using namespace std;

string quiz (string link, int sector = 0)
{
    ifstream text_link;
    string text;
    int number = 0;
    text_link.open (link);

    if (text_link.is_open())
    {
        while (!text_link.eof())
        {
           text_link >> number >> text;
        }
        if (number == sector)
        {
            return text;
        }
    }
    text_link.close ();
}


int main()
{
    vector <int> oldSector; // �������� ������
    int s = 13;
    int sector = 1;
    string textQ = "D:\\Skillbox\\question_e.txt";
    string textA = "D:\\Skillbox\\answer_e.txt";
    string answer;
    string correct_answer;
    int offset = 0;
    int connoisseurs = 0; // �������
    int spectators = 0; // �������

    cout << "What is our life? The game!\n";
    while (!(connoisseurs == 6 || spectators == 6))
    {
        cout << "Enter an offset, from 0 to 12: \n";
        cin >> offset;
        sector += offset;
        if (sector > s)
        {
            sector -= s;
        }
        for (int i = 0; i < oldSector.size(); i++)
        {
            if (sector == oldSector[i])
            {
                "The sector has already been played! \n";
            }
            else
            {
                cout << " Sector " << " " <<sector;
                cout << "Attention question!\n";
                cout << quiz (textQ, sector);
                cout <<  "Enter your answer: \n";
                cin >> answer;
                cout << "Attention! Correct answer: \n";
                correct_answer = quiz (textA, sector);
                cout << correct_answer;
                oldSector.push_back(sector);// ���������� ������ � ������� ��������

                if (answer == correct_answer)
                {
                    connoisseurs++;
                    cout << "Right! One point for the Connoisseurs!\n" << "Total score: \n";
                    cout << "Connoisseurs = " << connoisseurs << "::" << "Spectators = " << spectators;
                }
                else
                {
                    spectators++;
                    cout << "Right! One point for the Spectators!\n" << "Total score: \n";
                    cout << "Connoisseurs = " << connoisseurs << "::" << "Spectators = " << spectators;
                }
            }
        }
    }
    if (connoisseurs == 6)
    {
        cout << "Connoisseurs won!";
    }
    else
    {
        cout << "Spectators won!";
    }

     return 0;
}