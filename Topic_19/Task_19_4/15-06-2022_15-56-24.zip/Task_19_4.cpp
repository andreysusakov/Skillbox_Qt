#include <iostream>
#include <fstream>


using namespace std;

int main()
{
    ifstream fpng;
    string text;
    char buffer[5];

    cout << "Enter path to PNG file: \n";
    cin >> text;

    fpng.open(text, ios::binary);
    string sub = text.substr(text.size() - 3, 3);

    bool ok = (buffer[0] < 0) && (buffer[1] == 80) && (buffer[2] == 78) && (buffer[3] == 71);

    if(fpng.is_open() && sub == "PNG")
    {
        while(!sizeof (buffer))
        {
        fpng.read(buffer, sizeof(1));
        int count = fpng.gcount();
        buffer[count] = 0;
        }
    }
    else
    {
        cout << "No!";
    }

    if(ok)
    {
        cout << "Yes!";
    }
    else
    {
        cout << "No!";
    }
    cout << endl;

    cout << sub;

    fpng.close();

    return 0;
}

