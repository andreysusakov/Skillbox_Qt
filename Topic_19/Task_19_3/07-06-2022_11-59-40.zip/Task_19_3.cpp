#include <iostream>
#include <fstream>


using namespace std;

int main()
{
    ifstream statement;
    string name;
    string surname;
    string date;
    int sum = 0;
    int total = 0;
    string nameMax;
    string surnameMax;
    int sumMax = 0;

    statement.open("D:\\Skillbox\\words.txt");
    string is_open("D:\\Skillbox\\words.txt");


    while (!statement.eof())
    {
        statement >> name >> surname >> sum >> date;

        total += sum;

        if(sumMax < sum)
        {
            sumMax = sum;
            nameMax = name;
            surnameMax = surname;
        }
    }
    cout << "Total: " << total << "\n" << "Maximum payout amount " << sumMax << " at " << nameMax << " " << surnameMax << "." << endl;
    cout << endl;

    statement.close();

    return 0;
}

