#include <iostream>
#include <fstream>


using namespace std;

int main()
{
    ifstream schweik;
    string text;
    char buffer[100];

    cout << "Enter path to text file: \n";
    cin >> text;

    schweik.open(text, ios::binary);
    string is_open(text);


    while (!schweik.eof())
    {
        schweik.read(buffer, ' ' || schweik.gcount());
        buffer[99] = 0;
        cout << buffer;

    }
    cout << endl;

    schweik.close();

    return 0;
}

